"""Hardened loopback launcher for the bundled sidecar."""

from __future__ import annotations

import argparse
import json
import os
import socket
import sys
from pathlib import Path

import uvicorn

from paceback_engine.api import create_app
from paceback_engine.config import Settings


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the PaceBack local engine")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--development", action="store_true")
    return parser


def _read_startup_secrets(*, development: bool) -> tuple[str, str | None]:
    if development:
        token = os.getenv("PACEBACK_AUTH_TOKEN")
        if token:
            return token, os.getenv("PACEBACK_STORAGE_KEY")
    if sys.stdin.isatty():
        raise RuntimeError("Pass a one-line startup JSON object on stdin")
    try:
        payload = json.loads(sys.stdin.readline())
    except (json.JSONDecodeError, TypeError) as exc:
        raise RuntimeError("Startup stdin must be one valid JSON object") from exc
    if not isinstance(payload, dict) or set(payload) - {"authToken", "databaseKey"}:
        raise RuntimeError("Startup JSON accepts only authToken and databaseKey")
    token = payload.get("authToken")
    database_key = payload.get("databaseKey")
    if not isinstance(token, str) or not token:
        raise RuntimeError("Startup JSON requires authToken")
    if database_key is not None and not isinstance(database_key, str):
        raise RuntimeError("databaseKey must be a string")
    return token, database_key


def main() -> None:
    args = _parser().parse_args()
    token, database_key = _read_startup_secrets(development=args.development)
    data_dir = args.data_dir or (
        Path.home() / "Library" / "Application Support" / "PaceBack" / "Engine"
    )
    settings = Settings(
        data_dir=data_dir,
        auth_token=token,
        release_mode=not args.development,
        database_driver="sqlite" if args.development and not database_key else "sqlcipher",
        storage_key=database_key,
    )
    app = create_app(settings)
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("127.0.0.1", args.port))
    listener.listen(128)
    selected_port = listener.getsockname()[1]
    print(
        json.dumps(
            {
                "protocolVersion": "v1",
                "pid": os.getpid(),
                "port": selected_port,
                "ready": True,
            },
            separators=(",", ":"),
        ),
        flush=True,
    )
    config = uvicorn.Config(
        app,
        host="127.0.0.1",
        port=selected_port,
        access_log=False,
        server_header=False,
        date_header=False,
        log_level="warning",
    )
    uvicorn.Server(config).run(sockets=[listener])


if __name__ == "__main__":
    main()
